//
//  Calculator_framework.h
//  Calculator-framework
//
//  Created by Tiago Santo on 10/30/19.
//  Copyright © 2019 TiagoSanto. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Calculator_framework.
FOUNDATION_EXPORT double Calculator_frameworkVersionNumber;

//! Project version string for Calculator_framework.
FOUNDATION_EXPORT const unsigned char Calculator_frameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Calculator_framework/PublicHeader.h>


